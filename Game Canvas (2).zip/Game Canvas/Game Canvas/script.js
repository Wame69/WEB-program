const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Загружаем изображения
const dinoImg = new Image();
dinoImg.src = 'dino.png';
const cactusImg = new Image();
cactusImg.src = 'cactus.png';
const desertImg = new Image();
desertImg.src = 'background.jpg';

// Параметры динозавра
const dino = {
    x: 50,
    y: 150,
    width: 40,
    height: 50,
    dy: 0,
    gravity: 0.5,
    jumpPower: -10,
    isJumping: false
};

// Параметры кактусов
const cacti = [];
const cactusWidth = 30;
const cactusHeight = 50;
const cactusSpeed = 5;
let spawnCactusInterval = 1500;
let score = 0;
let gameOver = false;

document.addEventListener('keydown', function(e) {
    if (e.code === 'Space') {
        if (gameOver) {
            resetGame(); 
        } else if (!gameRunning) {
            startGame();
        }
    }   
});

// Обработчик прыжка (Space или стрелка вверх)
document.addEventListener('keydown', function(e) {
    if (e.code === 'Space' || e.key === 'ArrowUp') {
        if (!dino.isJumping && gameRunning) {
            dino.dy = dino.jumpPower;
            dino.isJumping = true;
        }
    }
});

// Запуск игры
function startGame() {
    gameRunning = true;
    setInterval(createCactus, spawnCactusInterval);
    updateGame();
}

// Сброс игры
function resetGame() {
    gameOver = false;
    score = 0;
    cacti.length = 0; // Очищаем массив кактусов
    dino.x = 50;
    dino.y = 150;
    dino.dy = 0;
    dino.isJumping = false;
    gameRunning = false;
    updateGame(); // Обновляем экран, чтобы отобразить начальное состояние
}

// Создание кактусов
function createCactus() {
    cacti.push({
        x: canvas.width,
        y: canvas.height - cactusHeight - 10,
        width: cactusWidth,
        height: cactusHeight
    });
}

// Обновление кактусов
function updateCacti() {
    for (let i = cacti.length - 1; i >= 0; i--) {
        cacti[i].x -= cactusSpeed;
        if (cacti[i].x + cactusWidth < 0) {
            cacti.splice(i, 1);
            score++;
        } else {
            if (detectCollision(dino, cacti[i])) {
                gameOver = true;
            }
        }
    }
}

// Проверка на столкновение
function detectCollision(dino, cactus) {
    return (
        dino.x < cactus.x + cactus.width &&
        dino.x + dino.width > cactus.x &&
        dino.y < cactus.y + cactus.height &&
        dino.y + dino.height > cactus.y
    );
}

// Отрисовка динозавра
function drawDino() {
    ctx.drawImage(dinoImg, dino.x, dino.y, dino.width, dino.height);
}

// Отрисовка кактусов
function drawCacti() {
    cacti.forEach(cactus => {
        ctx.drawImage(cactusImg, cactus.x, cactus.y, cactusWidth, cactusHeight);
    });
}

// Обновление положения динозавра (прыжок и гравитация)
function updateDino() {
    dino.y += dino.dy;

    if (dino.y + dino.height >= canvas.height - 10) {
        dino.y = canvas.height - dino.height - 10;
        dino.isJumping = false;
        dino.dy = 0;
    } else {
        dino.dy += dino.gravity;
    }
}

// Отрисовка счета
function drawScore() {
    ctx.font = '20px Arial';
    ctx.fillStyle = 'black';
    ctx.fillText('Score: ' + score, 10, 30);
}

// Отрисовка фона
function drawBackground() {
    ctx.drawImage(desertImg, 0, 0, canvas.width, canvas.height);
}

// Основная функция игры
function updateGame() {
    if (gameOver) {
        ctx.font = '30px Arial';
        ctx.fillStyle = 'black';
        ctx.fillText('Game Over! Нажмите Enter, чтобы перезапустить', canvas.width / 2 - 250, canvas.height / 2);
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawBackground();
    drawDino();
    drawCacti();
    drawScore();

    if (gameRunning) {
        updateDino();   
        updateCacti();
    }

    requestAnimationFrame(updateGame);
}

// Начальное состояние игры
let gameRunning = false; 