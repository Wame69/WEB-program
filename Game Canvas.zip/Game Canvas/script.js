const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const dino = {
    x: 50,
    y: 150,
    width: 30,
    height: 40,
    dy: 0,
    gravity: 0.5,
    jumpPower: -10,
    isJumping: false
};

// Параметры кактусов
const cacti = [];
const cactusWidth = 20;
const cactusHeight = 40;
const cactusSpeed = 5;
let spawnCactusInterval = 1500; // Интервал появления кактусов (1.5 секунды)

let score = 0;
let gameOver = false;

document.addEventListener('keydown', jump);

function jump(e) {
    if (e.code === 'Space' || e.key === 'ArrowUp') {
        if (!dino.isJumping) {
            dino.dy = dino.jumpPower;
            dino.isJumping = true;
        }
    }
}

// Создание кактусов
function createCactus() {
    cacti.push({
        x: canvas.width,
        y: canvas.height - cactusHeight - 10,
        width: cactusWidth,
        height: cactusHeight
    });
}

// Обновление кактусов
function updateCacti() {
    for (let i = 0; i < cacti.length; i++) {
        cacti[i].x -= cactusSpeed;

        // Удаление кактусов, которые вышли за границы экрана
        if (cacti[i].x + cactusWidth < 0) {
            cacti.splice(i, 1);
            score++;
        }

        // Проверка на столкновение
        if (detectCollision(dino, cacti[i])) {
            gameOver = true;
        }
    }
}

// Проверка на столкновение
function detectCollision(dino, cactus) {
    return (
        dino.x < cactus.x + cactus.width &&
        dino.x + dino.width > cactus.x &&
        dino.y < cactus.y + cactus.height &&
        dino.y + dino.height > cactus.y
    );
}

// Отрисовка динозавра
function drawDino() {
    ctx.fillStyle = 'green'; // Цвет динозавра
    ctx.fillRect(dino.x, dino.y, dino.width, dino.height); // Прямоугольник как динозавр
}

// Отрисовка кактусов
function drawCacti() {
    cacti.forEach(cactus => {
        ctx.fillStyle = 'darkgreen'; // Цвет кактуса
        ctx.fillRect(cactus.x, cactus.y, cactus.width, cactus.height); // Прямоугольник как кактус

        // Дополнительные "ветви" кактуса
        ctx.fillRect(cactus.x + 5, cactus.y - 20, 10, 20); // Верхняя часть кактуса
        ctx.fillRect(cactus.x - 5, cactus.y - 10, 10, 10); // Левая часть кактуса
        ctx.fillRect(cactus.x + 15, cactus.y - 10, 10, 10); // Правая часть кактуса
    });
}

// Обновление положения динозавра (прыжок и гравитация)
function updateDino() {
    dino.y += dino.dy;

    if (dino.y + dino.height >= canvas.height - 10) {
        dino.y = canvas.height - dino.height - 10; // Остановка динозавра на земле
        dino.isJumping = false;
        dino.dy = 0;
    } else {
        dino.dy += dino.gravity;
    }
}

// Отрисовка счета
function drawScore() {
    ctx.font = '20px Arial';
    ctx.fillStyle = 'black';
    ctx.fillText('Score: ' + score, 10, 30);
}

// Основная функция игры
function updateGame() {
    if (gameOver) {
        ctx.font = '30px Arial';
        ctx.fillStyle = 'black';
        ctx.fillText('Game Over!', canvas.width / 2 - 80, canvas.height / 2);
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawDino();
    drawCacti();
    drawScore();

    updateDino();
    updateCacti();

    requestAnimationFrame(updateGame);
}

// Запуск игры и создание кактусов
setInterval(createCactus, spawnCactusInterval);
updateGame();
