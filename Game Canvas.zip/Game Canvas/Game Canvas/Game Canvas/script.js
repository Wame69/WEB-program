const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Загружаем изображения для анимации динозавра
const dinoImages = {
    run: [
        new Image(), // Левая нога вверх
        new Image()  // Правая нога вверх
    ],
    duck: [
        new Image(), // В положении пригибания с левой ногой
        new Image()  // В положении пригибания с правой ногой
    ]
};
dinoImages.run[0].src = 'Dino-left-up.png';
dinoImages.run[1].src = 'Dino-right-up.png';
dinoImages.duck[0].src = 'Dino-below-left-up.png';
dinoImages.duck[1].src = 'Dino-below-right-up.png';

// Остальные изображения
const cactusImg = new Image();
cactusImg.src = 'cactus.png';
const birdImg = new Image();
birdImg.src = 'bird.png';
const desertImg = new Image();
desertImg.src = 'Desert.png';

// Параметры динозавра
const dino = {
    x: 50,
    y: 150,
    width: 40,
    height: 50,
    dy: 0,
    gravity: 0.5,
    jumpPower: -10,
    isJumping: false,
    isDucking: false,
    frame: 0  // Кадр анимации
};

// Параметры кактусов и птиц
const cacti = [];
const birds = [];
let cactusInterval = 150;
let birdInterval = 150; // Интервал появления птиц

// Остальные параметры игры
let score = 0;
let gameOver = false;
let gameRunning = false;
let backgroundX = 0;
let animationFrame = 0; // Счетчик для переключения кадров
let speed = 1.0; // Скорость игры, увеличивается с ростом счёта

// Обработчик клавиш
document.addEventListener('keydown', function(e) {
    if (e.code === 'KeyW') { // Клавиша W для прыжка
        if (gameOver) {
            resumeGame();
        } else if (!gameRunning) {
            startGame();
        } else if (!dino.isJumping && !dino.isDucking) {
            dino.dy = dino.jumpPower;
            dino.isJumping = true;
        }
    } else if (e.code === 'KeyS') { // Клавиша S для пригибания
        dino.isDucking = true;
    }
});

document.addEventListener('keyup', function(e) {
    if (e.code === 'KeyS') {
        dino.isDucking = false;
    }
});

// Запуск игры
function startGame() {
    gameRunning = true;
    backgroundX = 0;
    canvas.style.display = 'block'; 
    document.getElementById('startScreen').style.display = 'none'; 
    updateGame();
}

// Возобновление игры после окончания с обнулением счёта
function resumeGame() {
    gameOver = false;
    gameRunning = true;
    dino.y = 150;
    dino.dy = 0;
    dino.isJumping = false;
    dino.isDucking = false;
    score = 0;
    speed = 1.0;
    cactusInterval = 150;
    birdInterval = 300;
    cacti.length = 0;
    birds.length = 0;
    updateGame(); 
}

// Функция для генерации новых кактусов
function createCactus() {
    cacti.push({
        x: canvas.width,
        y: canvas.height - 55,
        width: 30,
        height: 50
    });
}

// Функция для генерации новых птиц
function createBird() {
    const birdHeight = 5; // Позиция птицы над землей
    birds.push({
        x: canvas.width,
        y: canvas.height - 74 - birdHeight, // Расположим птицу немного выше
        width: 30,
        height: 20
    });
}

// Функция для обновления скорости
function updateSpeed() {
    if (score >= 1500 && score % 1000 === 0) {
        speed += 0.5; // Увеличиваем скорость
        cactusInterval = Math.max(100, cactusInterval - 10); // Уменьшаем интервал кактусов
        birdInterval = Math.max(200, birdInterval - 20); // Уменьшаем интервал птиц
    }
}

// Обновление кактусов и птиц с рандомным порядком появления
function updateObstacles() {
    updateSpeed(); // Обновляем скорость при обновлении препятствий

    if (score >= 500 && animationFrame % Math.floor(birdInterval / speed) === 0) {
        const randomChoice = Math.random();
        
        if (birds.length === 0 && randomChoice < 0.5) {
            createBird();
        } else if (cacti.length === 0 && randomChoice >= 0.5) {
            createCactus();
        }
    } else if (animationFrame % Math.floor(cactusInterval / speed) === 0) {
        if (birds.length === 0) {
            createCactus();
        }
    }

    for (let i = cacti.length - 1; i >= 0; i--) {
        cacti[i].x -= 5 * speed;
        if (cacti[i].x + cacti[i].width < 0) {
            cacti.splice(i, 1);
        }
    }

    for (let i = birds.length - 1; i >= 0; i--) {
        birds[i].x -= 6 * speed;
        if (birds[i].x + birds[i].width < 0) {
            birds.splice(i, 1);
        }
    }
}

// Отрисовка кактусов
function drawCacti() {
    cacti.forEach(cactus => {
        ctx.drawImage(cactusImg, cactus.x, cactus.y, cactus.width, cactus.height);
    });
}

// Отрисовка птиц
function drawBirds() {
    birds.forEach(bird => {
        ctx.drawImage(birdImg, bird.x, bird.y, bird.width, bird.height);
    });
}

// Отрисовка динозавра с анимацией
function drawDino() {
    const images = dino.isDucking ? dinoImages.duck : dinoImages.run;
    if (animationFrame % 10 === 0) {
        dino.frame = (dino.frame + 1) % images.length;
    }

    if (dino.isDucking) {
        // Смещаем динозавра ниже и уменьшаем его высоту
        const duckYPosition = dino.y + 20; // Смещение вниз при пригибании
        ctx.drawImage(images[dino.frame], dino.x, duckYPosition, dino.width, dino.height - 20);
    } else {
        // Отображаем динозавра в нормальной позе
        ctx.drawImage(images[dino.frame], dino.x, dino.y, dino.width, dino.height);
    }
}

// Проверка столкновений
function checkCollision() {
    // Проверяем столкновение с кактусами
    for (const cactus of cacti) {
        if (
            dino.x < cactus.x + cactus.width &&
            dino.x + dino.width > cactus.x &&
            dino.y < cactus.y + cactus.height &&
            dino.y + dino.height > cactus.y
        ) {
            gameOver = true;
            return;
        }
    }

    // Проверяем столкновение с птицами
    for (const bird of birds) {
        // Если динозавр пригнулся, уменьшаем его высоту для проверки столкновения
        const dinoHeight = dino.isDucking ? dino.height - 20 : dino.height;
        const dinoY = dino.isDucking ? dino.y + 20 : dino.y;

        if (
            dino.x < bird.x + bird.width &&
            dino.x + dino.width > bird.x &&
            dinoY < bird.y + bird.height &&
            dinoY + dinoHeight > bird.y
        ) {
            gameOver = true;
            return;
        }
    }
}

// Обновление положения динозавра
function updateDino() {
    dino.y += dino.dy;
    if (dino.y + dino.height >= canvas.height - 10) {
        dino.y = canvas.height - dino.height - 10;
        dino.isJumping = false;
        dino.dy = 0;
    } else {
        dino.dy += dino.gravity;
    }
}

// Отрисовка фона
function drawBackground() {
    ctx.drawImage(desertImg, backgroundX, 0, canvas.width, canvas.height);
    ctx.drawImage(desertImg, backgroundX + canvas.width, 0, canvas.width, canvas.height);
    backgroundX -= 2 * speed;
    if (backgroundX <= -canvas.width) {
        backgroundX = 0;
    }
}

// Отрисовка счёта
function drawScore() {
    ctx.font = '20px Arial';
    ctx.fillStyle = 'black';
    ctx.fillText('Score: ' + score, 10, 30);
    score += 1;
}

// Основная функция игры
function updateGame() {
    if (gameOver) {
        ctx.font = '30px Arial';
        ctx.fillStyle = 'black';
        ctx.fillText('Game Over! Нажмите W, чтобы перезапустить', canvas.width / 2 - 250, canvas.height / 2);
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawBackground();
    drawDino();
    drawCacti();
    drawBirds();
    drawScore();

    if (gameRunning) {
        updateDino();
        updateObstacles();
        checkCollision(); // Проверка столкновений
    }

    animationFrame++;
    requestAnimationFrame(updateGame);
}

// Показать правила
function showRules() {
    document.getElementById('startScreen').style.display = 'none';
    document.getElementById('rulesScreen').style.display = 'block';
}

// Скрыть правила
function hideRules() {
    document.getElementById('rulesScreen').style.display = 'none';
    document.getElementById('startScreen').style.display = 'block';
}
